[![Build Status](https://travis-ci.com/sahyam2019/oub-remix.svg?branch=sql-extended)](https://travis-ci.com/sahyam2019/oub-remix) [![Codacy Badge](https://app.codacy.com/project/badge/Grade/38fee611df7c4312be63a15cad64a50a)](https://www.codacy.com/manual/sahyam2019/oub-remix?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=sahyam2019/oub-remix&amp;utm_campaign=Badge_Grade) ![Last Commit](https://img.shields.io/github/last-commit/sahyam2019/oub-remix) ![Contributers](https://img.shields.io/github/contributors/sahyam2019/oub-remix) ![Forks](https://img.shields.io/github/forks/sahyam2019/oub-remix)     
# Project OpenUserBot Remix

![logo](https://telegra.ph/file/b17eb811d1666426e7f3b.jpg)

```
#include <std/disclaimer.h>
/**
    Your Telegram account may get banned.
    I am not responsible for any improper use of this bot
    This bot is intended for the purpose of having fun with memes,
    as well as efficiently managing groups.
    You ended up spamming groups, getting reported left and right,
    and you ended up in a Finale Battle with Telegram and at the end
    Telegram Team deleted your account?
    And after that, then you pointed your fingers at us
    for getting your account deleted?
    I will be rolling on the floor laughing at you.
    No personal support will be provided/I won't spoonfeed. If you need help ask in 
    support group mentioned below or ask your friend.
    Open issues if you think there's a bug/problem.
    Open pr if you think you can improve the existing code.
    #stayremixed
/**
```

## How To Host?

The easiest way to deploy this great bot! is click on button below
Make sure you have an account of heroku and follow all the steps required.

Deploy to Heroku:
<p align="left"><a href="https://heroku.com/deploy?template=https://github.com/sahyam2019/oub-remix/tree/sql-extended"> <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy to Heroku" /></a></p>

## Groups and support

If you want new features, or announcements, you can follow our [oub-remix Channel](https://t.me/oubremix).

For discussion, bug reporting, and help, you can join [oub-remix support Group](https://t.me/remixsupport).

## How to setup Google Drive
[![SetGDRIVE](https://telegra.ph/file/fde15d05e4bde3448b01a.png)](https://telegra.ph/How-To-Setup-Google-Drive-04-03)

## Credits

Thanks for all : 
* [Baalaji maestro (RaphielGang)](https://github.com/RaphielGang) - Telegram-Paperplane
* [AvinashReddy3108](https://github.com/AvinashReddy3108) - PaperplaneExtended
* [Mkaraniya](https://github.com/mkaraniya) - OpenUserBot
* [DevPatel](https://github.com/Devp73) - OpenUserBot
* [༺αиυвιѕ༻](https://github.com/Dark-Princ3) - X-tra-Telegram
* [MoveAngel](https://github.com/MoveAngel) - One4uBot
* [keselekpermen69](https://github.com/keselekpermen69) - UserButt

and many more people who aren't mentioned here, but may be found in [Contributors](https://github.com/sahyam2019/oub-remix/graphs/contributors).

## License

This userbot licensed on [Raphielscape Public License](https://github.com/sahyam2019/oub-remix/blob/sql-extended/LICENSE) - Version 1.d, February 2020
